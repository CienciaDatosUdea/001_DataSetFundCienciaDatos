OK_FORMAT = True

test = {   'name': 'q4_1',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> assert isinstance(mayor_diferencia, int)\n>>> assert mayor_diferencia > 0\n', 'hidden': False, 'locked': False},
                                   {'code': '>>> assert mayor_diferencia == 45\n', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
