OK_FORMAT = True

test = {   'name': 'q4_2',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> assert isinstance(menor_cambio_programa, int)\n>>> assert menor_cambio_programa >= 0\n', 'hidden': False, 'locked': False},
                                   {'code': '>>> assert menor_cambio_programa == 0\n', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
