OK_FORMAT = True

test = {   'name': 'q6_1',
    'points': None,
    'suites': [   {   'cases': [   {   'code': '>>> assert isinstance(respuesta_supervivientes, int)\n>>> assert respuesta_supervivientes >= 0\n>>> assert 1 <= respuesta_supervivientes <= 3\n',
                                       'hidden': False,
                                       'locked': False},
                                   {'code': '>>> assert respuesta_supervivientes == 1\n', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
