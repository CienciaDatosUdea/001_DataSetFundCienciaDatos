OK_FORMAT = True

test = {   'name': 'q3_1',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> assert isinstance(nombres_q1, int)\n>>> assert 1 <= nombres_q1 <= 4\n', 'hidden': False, 'locked': False},
                                   {'code': '>>> assert nombres_q1 == 2\n', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
