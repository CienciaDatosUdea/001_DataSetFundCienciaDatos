OK_FORMAT = True

test = {'name': 'q7_2', 'points': None, 'suites': [{'cases': [{'code': '>>> assert calificacion == 2\n', 'hidden': True, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
